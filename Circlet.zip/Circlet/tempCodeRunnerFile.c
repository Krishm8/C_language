for (int j = i; j >= 1; j--)
        {
            printf(" %d",j);
        }